export interface Staff {
    id: number;
    fullName: string;
    dpmt: string;
    gender: string;
    qualification: string;
    phone: number;
    emailId: string;
}
