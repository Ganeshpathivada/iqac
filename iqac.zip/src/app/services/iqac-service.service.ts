import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class IqacServiceService {

  faculityData:any;

  constructor() { }
}
